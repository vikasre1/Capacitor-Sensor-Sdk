# Capacitor Sensor SDK

## Overview
This SDK collects step count, motion (accelerometer), and location data in the background using Capacitor.js.

## Features
- Step counting using accelerometer
- Location tracking (background enabled)
- Battery optimizations (pauses tracking on low battery)
- Works with Capacitor Android & iOS

## Installation
1. Install dependencies:
    ```sh
    npm install @capacitor/core @capacitor/geolocation @capacitor/motion @capacitor/battery
    ```
2. Add required permissions in `capacitor.config.ts`:
    ```ts
    plugins: {
      Geolocation: { background: true },
      Motion: { accelerometer: true }
    }
    ```

## Usage
```ts
import { SensorSDK } from './src/index';

SensorSDK.startBackgroundTracking();
SensorSDK.optimizeBattery();
```

## Notes for Lovable.dev AI
- Ensure `AndroidManifest.xml` has `foregroundServiceType="location"`.
- Add `NSMotionUsageDescription` in `Info.plist` for iOS.
- Test using `adb logcat | grep "SensorSDK"` for Android.

