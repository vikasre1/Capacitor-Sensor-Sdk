
// src/index.ts
import { Plugins } from '@capacitor/core';

const { Geolocation, Motion, Battery } = Plugins;

export class SensorSDK {
  static async startBackgroundTracking() {
    try {
      // Request permissions
      await Geolocation.requestPermissions();
      await Motion.requestPermissions();

      // Start tracking sensors
      Motion.addListener('accel', (event) => {
        console.log('Acceleration:', event);
      });

      Geolocation.watchPosition({}, (position) => {
        console.log('Location:', position);
      });

      console.log("Background tracking started.");
    } catch (error) {
      console.error("Failed to start tracking:", error);
    }
  }

  static async stopBackgroundTracking() {
    console.log("Background tracking stopped.");
  }

  static async optimizeBattery() {
    Battery.addListener('batteryStatus', (status) => {
      if (status.batteryLevel < 20 && !status.charging) {
        console.warn("Low battery! Pausing tracking to save power.");
        this.stopBackgroundTracking();
      }
    });
  }
}
